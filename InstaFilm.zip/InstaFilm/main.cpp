/**
    GNU GCC 8.1 C++17
    main.cpp
    Purpose: InstaFilm una aplicación de red social de películas.

    @author Juana Valentina Mendoza Santamaría (juana.mendoz4@gmail.com)
    @version 1.0 10/10/2018
*/

#include <iostream>
#include "bienvenida.h"

using namespace std;

int main()
{
    menu_bienvenida();

    return 0;
}

